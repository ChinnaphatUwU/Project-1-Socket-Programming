"""Persistent TCP client for QAP."""

import json
import socket

HOST = "127.0.0.1"
PORT = 8080


class QAPClient:
    def __init__(self, host=HOST, port=PORT, keep_alive=True, verbose=True):
        self.host = host
        self.port = port
        self.keep_alive = keep_alive
        self.verbose = verbose
        self.socket = None
        self.buffer = b""
        self.session_id = None
        self.fragments = {}
        self.connection_count = 0

    def _log(self, message):
        if self.verbose:
            print(message)

    def connect(self):
        if self.socket is None:
            try:
                self.socket = socket.create_connection((self.host, self.port), timeout=10)
                self.socket.settimeout(10)
                self.connection_count += 1
            except OSError as exc:
                raise ConnectionError(
                    "Server is not running on port 8080. Start 'python server.py' in the project folder first."
                ) from exc

    def close(self):
        if self.socket is not None:
            try:
                self.socket.close()
            finally:
                self.socket = None
                self.buffer = b""

    def _read_until(self, marker):
        while marker not in self.buffer:
            chunk = self.socket.recv(4096)
            if not chunk:
                raise ConnectionError("Server closed the connection unexpectedly")
            self.buffer += chunk
        position = self.buffer.index(marker)
        result = self.buffer[:position]
        self.buffer = self.buffer[position + len(marker):]
        return result

    def _read_exact(self, size):
        while len(self.buffer) < size:
            chunk = self.socket.recv(min(65536, size - len(self.buffer)))
            if not chunk:
                raise ConnectionError("Server closed before the response body was complete")
            self.buffer += chunk
        result = self.buffer[:size]
        self.buffer = self.buffer[size:]
        return result

    def request(self, method, path, body=None, extra_headers=None):
        self.connect()
        body_bytes = b"" if body is None else json.dumps(body, ensure_ascii=False).encode("utf-8")
        headers = {
            "Host": f"{self.host}:{self.port}",
            "X-Protocol": "QAP",
            "Connection": "keep-alive" if self.keep_alive else "close",
        }
        if self.session_id:
            headers["X-Session-ID"] = self.session_id
        if body is not None:
            headers["Content-Type"] = "application/json"
            headers["Content-Length"] = str(len(body_bytes))
        if extra_headers:
            headers.update(extra_headers)

        request_head = f"{method} {path} HTTP/1.1\r\n"
        request_head += "".join(f"{key}: {value}\r\n" for key, value in headers.items())
        request_bytes = (request_head + "\r\n").encode("utf-8") + body_bytes

        self._log(f"[CLIENT] >> REQUEST: {method} {path} QAP")
        if self.session_id:
            self._log(f"[CLIENT]    X-Session-ID: {self.session_id}")
        if body is not None:
            self._log(f"[CLIENT]    Body: {json.dumps(body, ensure_ascii=False)}")

        try:
            self.socket.sendall(request_bytes)
            header_block = self._read_until(b"\r\n\r\n").decode("iso-8859-1")
        except (ConnectionError, OSError, TimeoutError, ValueError) as exc:
            self.close()
            raise ConnectionError(
                "Server closed the connection during the request. Check that only one server.py is running on port 8080."
            ) from exc

        try:
            lines = header_block.split("\r\n")
            status_parts = lines[0].split(" ", 2)
            if len(status_parts) != 3:
                raise ValueError("Malformed response status line")
            http_status = int(status_parts[1])
            response_headers = {}
            for line in lines[1:]:
                key, value = line.split(":", 1)
                response_headers[key.strip().lower()] = value.strip()
            content_length = int(response_headers.get("content-length", "0"))
            response_body = self._read_exact(content_length)

            received_session = response_headers.get("x-session-id")
            if received_session:
                self.session_id = received_session
            fragment = response_headers.get("x-flag-fragment")
            fragment_index = response_headers.get("x-flag-fragment-index")
            if fragment and fragment_index:
                self.fragments[int(fragment_index)] = fragment
                self._log(f"[CLIENT]    X-Flag-Fragment-{fragment_index}: {fragment}")

            data = json.loads(response_body.decode("utf-8")) if response_body else {}
            qap_status = data.get("qap_status", data.get("status"))
            qap_phrase = data.get("qap_phrase", data.get("status_phrase"))
            self._log(f"[CLIENT] << RESPONSE: QAP {qap_status} {qap_phrase}")

            if not self.keep_alive or response_headers.get("connection", "").lower() == "close":
                self.close()
            return http_status, response_headers, data
        except (ConnectionError, OSError, TimeoutError, ValueError, json.JSONDecodeError) as exc:
            self.close()
            raise ConnectionError(
                "The server response was incomplete or malformed. Restart server.py and retry with only one running instance."
            ) from exc

    def assembled_flag(self):
        return "".join(self.fragments[index] for index in sorted(self.fragments))

    def __enter__(self):
        self.connect()
        return self

    def __exit__(self, exc_type, exc_value, traceback):
        self.close()


def play_quiz():
    print("=" * 60)
    print(" QAP Quiz Client - one persistent TCP connection")
    print("=" * 60)
    try:
        with QAPClient() as client:
            status, _, start = client.request("GET", "/api/start")
            if status != 200:
                print("Unable to start:", start)
                return

            question_ids = start["question_ids"]
            for position, question_id in enumerate(question_ids, 1):
                _, _, result = client.request("GET", f"/api/question/{question_id}")
                question = result["question"]
                print(f"\nQuestion {position}/{len(question_ids)}: {question['question']}")
                print(f"Image: {', '.join(question['images'])}")
                for index, choice in enumerate(question["choices"], 1):
                    print(f"  {index}. {choice}")
                while True:
                    try:
                        answer = int(input("Answer (1-4): ")) - 1
                        if 0 <= answer < len(question["choices"]):
                            break
                    except ValueError:
                        print("Please enter a number from 1 to 4.")
                        continue
                    except EOFError:
                        print("\nInput closed. Please run the client in an interactive terminal and answer each question.")
                        return
                    print("Please enter a number from 1 to 4.")

                _, _, answer_result = client.request(
                    "POST", f"/api/answer/{question_id}", {"answer": answer}
                )
                print("CORRECT" if answer_result.get("correct") else "WRONG")

            _, _, score_result = client.request("POST", "/api/score", {})
            print(f"\nAuthoritative score: {score_result['score']}/{score_result['total']}")
            print(f"TCP connections used: {client.connection_count}")
            if score_result.get("perfect"):
                print("Fragments in order:")
                for index in sorted(client.fragments):
                    print(f"  {index}: {client.fragments[index]}")
                print("Assembled flag:", client.assembled_flag())
                if score_result.get("perfect") and len(client.fragments) == score_result["total"]:
                    print("Secret URL from fragments:", "/" + client.assembled_flag())
                else:
                    print("Secret URL: Fragments incomplete")
            else:
                print("Perfect score required to complete the flag chain.")
    except ConnectionError as exc:
        print(f"\nConnection error: {exc}")
        print("Make sure only one server.py is running on port 8080 before retrying.")
    except KeyboardInterrupt:
        print("\nClient stopped by user.")


if __name__ == "__main__":
    play_quiz()
