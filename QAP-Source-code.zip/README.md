# QAP — Quiz Application Protocol

โปรเจกต์นี้เป็นแอปพลิเคชันเกมตอบคำถามที่ทำงานบน TCP แบบ raw socket และมีลักษณะคล้าย HTTP request/response อย่างง่าย แต่มี session state, flag fragment, image upload และ keep-alive connection เพื่อให้เกมมีความสมจริงและมีความท้าทายด้าน network protocol

## 1. ภาพรวมของโปรเจกต์
QAP ประกอบด้วย 3 ส่วนหลัก:
- Server: `server.py` รันบนพอร์ต 8080 และจัดการ session, คำถาม, การตรวจคำตอบ, การให้คะแนน, และการแจก flag fragment
- Browser client: หน้าเว็บใน `web/` ให้ผู้เล่นเริ่มเกม, ดูคำถาม, ส่งคำตอบ และไปยังหน้าคะแนน
- Terminal client: `client.py` ใช้ TCP connection แบบ persistent เพื่อสาธิตการส่งคำขอและรับคำตอบแบบเดียวกับเกมจริง

ฟีเจอร์สำคัญคือเมื่อผู้เล่นตอบถูกแต่ละข้อ Server จะส่ง header `X-Flag-Fragment` และ `X-Flag-Fragment-Index` กลับไปใน response ชิ้นละหนึ่งส่วน ต้องนำ fragment ทั้งหมดมารวมกันเพื่อสร้าง path ของหน้า secret ที่ถูกซ่อนอยู่

## 2. สิ่งที่โปรเจกต์ทำได้จริงในปัจจุบัน
- เริ่ม session ใหม่ด้วย `GET /api/start`
- ดึงคำถามผ่าน `GET /api/question/{id}`
- ส่งคำตอบด้วย `POST /api/answer/{id}`
- ขอคะแนนแบบสรุปด้วย `POST /api/score`
- ใช้ `X-Session-ID` เพื่อบันทึก progress ของแต่ละผู้เล่นบน server
- ตรวจคำตอบที่ฝั่ง server เท่านั้น ไม่ยอมรับคะแนนจาก client
- ป้องกันการตอบซ้ำสำหรับคำถามเดิม
- รองรับการสร้างคำถามใหม่ผ่านหน้าเว็บ และอัปโหลดรูปภาพ PNG/JPEG/GIF ได้สูงสุด 5 MiB
- รองรับการลบคำถามจาก catalog โดยมีเงื่อนไขไม่ให้ลบคำถามสุดท้ายได้
- แสดงหน้า secret เมื่อผู้เล่นได้คะแนนเต็มและรวม fragment ได้ถูกต้อง
- ทำ benchmark concurrency และ keep-alive ด้วย `stress_test.py`

## 3. สถาปัตยกรรมและโครงสร้าง
```text
network/
├── server.py              # TCP server หลัก
├── client.py              # Python client แบบ persistent
├── stress_test.py         # Benchmark สำหรับ concurrency และ keep-alive
├── questions.json         # คำถามปัจจุบันที่ใช้งานจริง
├── stress_results.csv     # ผล benchmark ล่าสุด
├── images/                # รูปภาพที่ใช้งานและอัปโหลด
├── web/
│   ├── index.html         # หน้าเล่น Quiz
│   ├── score.html         # หน้าสรุปคะแนน
│   └── create.html        # หน้าสร้าง/ลบคำถาม
├── secret/
│   └── index.html         # หน้า secret
├── __pycache__/           # cache ของ Python
└── questions.json         # catalog ของคำถาม
```

## 4. วิธีรันโปรเจกต์
ต้องใช้ Python 3 และไม่มี dependency ภายนอก (ใช้ไลบรารีมาตรฐานของ Python เท่านั้น)

```powershell
Set-Location "c:\Users\chinn\Documents\network"
python server.py
```

จากนั้นเปิดได้ดังนี้:
- Web quiz: http://127.0.0.1:8080/
- Create question: http://127.0.0.1:8080/create.html
- Terminal client: `python client.py`
- Benchmark: `python stress_test.py --clients 10 25 50`

## 5. การทำงานของเกม
### 5.1 Session และ snapshot
เมื่อเริ่มเกมใหม่ Server จะสร้าง session และเก็บ snapshot ของคำถามทั้งหมดไว้ในหน่วยความจำ ตัวอย่าง:
- `GET /api/start`
- Server คืนค่า JSON ที่มี `session_id`, `total_questions`, และ `question_ids`
- ทุกคำถามและการตอบถูกเก็บใน session นั้นเท่านั้น
- เมื่อตั้งค่า session แล้ว server จะไม่ให้ session ที่ค้างอยู่ถูกใช้ร่วมกันกับ session ใหม่

### 5.2 การเรียกใช้คำถาม
เมื่อผู้เล่นต้องการคำถามแต่ละข้อ:
- `GET /api/question/{id}`
- Server จะส่งข้อมูลคำถามแบบ public ที่มีเฉพาะ:
  - `id`
  - `question`
  - `images`
  - `choices`
- `answer` หรือข้อมูลเฉลยจริงไม่ได้ถูกส่งให้ client

### 5.3 การตอบคำถาม
เมื่อผู้เล่นส่งคำตอบ:
- `POST /api/answer/{id}`
- Server ตรวจว่าคำถามมีอยู่และคำตอบอยู่ในช่วงที่ถูกต้อง
- ถ้าตอบถูกจะเพิ่มคะแนน 1 และส่ง header เพิ่มเติมดังนี้:
  - `X-Flag-Fragment`
  - `X-Flag-Fragment-Index`
- ถ้าตอบผิด จะส่งสถานะ `WRONG` โดยไม่มี fragment
- Server ยังป้องกันการตอบซ้ำด้วยการตรวจว่า `question_id` นี้ได้ถูกส่งไปแล้วหรือยัง

### 5.4 การคำนวณคะแนน
เมื่อผู้เล่นตอบครบทุกข้อแล้ว:
- `POST /api/score`
- Server จะตรวจว่า answered ครบหรือยัง
- Server คืนค่า JSON ที่มี:
  - `score`
  - `total`
  - `perfect`
  - `fragments_earned`
- `perfect` จะเป็น `true` ก็ต่อเมื่อ ทุกคำถามถูกตอบถูกหมด และมี fragment ครบตามจำนวนคำถาม

## 6. โปรโตคอลที่ใช้
โปรเจกต์นี้ไม่ได้ใช้ framework web แบบปกติ แต่ใช้ custom protocol ที่มีลักษณะคล้าย HTTP/1.1:
- ทุก request เริ่มด้วย method, path, HTTP version
- Header จะมี `X-Protocol: QAP`
- Body JSON ถูกส่งหากมี payload
- Response มี status line แบบ HTTP เช่น `HTTP/1.1 200 OK`
- Session ระบุต่อผู้เล่นผ่าน header `X-Session-ID`
- ตัวอย่าง header ที่สำคัญ:
  - `X-Session-ID`
  - `X-Flag-Fragment`
  - `X-Flag-Fragment-Index`

## 7. การสร้างคำถามและอัปโหลดรูป
หน้า `create.html` ทำงานกับ API ต่อไปนี้:
- `GET /api/quiz/questions` — ดูรายการคำถามทั้งหมด
- `POST /api/quiz/create` — สร้างคำถามพร้อมรูป
- `DELETE /api/quiz/question/{id}` — ลบคำถาม

รูปภาพต้องเป็นชนิด:
- PNG
- JPEG
- GIF

และต้องมีขนาดไม่เกิน 5 MiB

กระบวนการ:
1. หน้าเว็บอ่านไฟล์รูปจากอินพุต
2. แปลงเป็น Base64
3. ส่ง JSON ไปยัง `/api/quiz/create`
4. Server ตรวจ MIME type และ signature ของไฟล์
5. Server บันทึกไฟล์เป็นชื่อ random และ persist ลง `questions.json`

ข้อควรจำ: คำถามที่เพิ่งสร้างหรือเพิ่งลบ จะมีผลต่อ session ใหม่เท่านั้น เพราะ session เก่าจะมี snapshot ของคำถามที่เป็นของตัวเองอยู่แล้ว

## 8. ความปลอดภัยและเงื่อนไขการใช้งาน
Server มีการป้องกันหลายด้าน:
- ป้องกัน `X-Session-ID` ที่หายไปหรือไม่ถูกต้อง
- ป้องกันคำถามซ้ำใน session เดียว
- ป้องกันคำตอบที่อยู่นอกช่วง index
- จำกัดความยาว header และ body
- ตรวจ MIME/signature ของรูปก่อนบันทึก
- ป้องกัน path traversal สำหรับไฟล์ static
- ป้องกันการลบคำถามสุดท้ายใน catalog
- ไม่เผย `answer` ให้ผู้เล่นเห็นจาก response

## 9. ความหมายของ flag fragment
เมื่อผู้เล่นตอบถูกคำถามแต่ละข้อ server จะมอบ fragment ของ secret flag เพียงแค่ 1 ส่วนต่อคำถาม โดย fragment จะถูกจัดเรียงตาม index ของคำถามใน session

ขั้นตอนการได้ secret path:
1. ตอบคำถามครบทุกคำถาม
2. รวบรวม header `X-Flag-Fragment` จากทุกคำตอบที่ถูก
3. เรียงตาม `X-Flag-Fragment-Index`
4. ต่อ string ให้เป็น flag
5. ใช้ `/` + flag เป็น path เพื่อเปิดหน้า secret

## 10. การทดสอบความสามารถและประสิทธิภาพ
ไฟล์ `stress_test.py` นำ `client.py` มาใช้เพื่อ benchmark การทำงานของ server แบบ concurrent load test

สิ่งที่ทำได้:
- สร้างผู้เล่นหลายคนพร้อมกัน
- เปรียบเทียบการใช้งาน keep-alive กับการปิด connection ทุกรอบ
- บันทึกผลเป็นตารางและไฟล์ CSV

ตัวอย่างคำสั่ง:
```powershell
python stress_test.py --clients 10 25 50
```

ผลลัพธ์ที่ได้จะรวม:
- จำนวน client
- success rate
- เวลาเฉลี่ยและ p95
- จำนวน TCP connection ที่ใช้
- การบันทึกลง `stress_results.csv`

## 11. จุดเด่นของการออกแบบ
- ชุดอุปกรณ์ที่เป็นของโปรเจกต์เอง ไม่ต้องติดตั้ง dependency เพิ่ม
- ใช้หลักการ `raw TCP` จริง เพื่อฝึกเรื่อง socket, framing, parsing, session handling และ concurrency
- มีทั้งส่วนเล่นผ่าน browser และผ่าน terminal client
- มีฟีเจอร์ upload, session snapshot, benchmark และ flag chaining อยู่ในโครงการเดียว

## 12. หมายเหตุสำหรับการใช้งาน
- Server ต้องรันก่อนเสมอก่อนเริ่ม client หรือ benchmark
- หากมีหลาย instance ของ `server.py` รันพร้อมกันจะทำให้พอร์ต 8080 และ session เกิดความสับสน
- เกมถูกออกแบบให้เป็น challenge/prototype สำหรับฝึก network programming ไม่ใช่ผลิตภัณฑ์ระดับ production

## 13. สรุปสั้น ๆ
QAP เป็นโปรเจกต์เกมคำถามที่ใช้ session บน TCP, custom HTTP-like protocol, image upload, keep-alive socket, benchmarking และการซ่อน secret path ผ่าน flag fragment ที่แจกทีละชิ้นจากการตอบถูกทุกคำถาม โปรแกรมนี้เหมาะสำหรับผู้ที่ต้องการฝึกเรื่อง socket, protocol parsing, multi-thread server, security checks และ client/server design อย่างเป็นรูปธรรมใช้ 1 connection จึงลด connection setup 11 ครั้ง Server ใช้ `Content-Length` แบ่ง response จึงไม่ต้องรอ socket ปิด และ parser เก็บ bytes ส่วนเกินไว้สำหรับ request ถัดไป หากเพิ่มคำถามเป็น 6 ข้อ เกมใหม่จะใช้ 14 requests ดังนั้นต้องรัน benchmark และบันทึกจำนวนข้อให้ตรงกัน
## 11. Concurrent Load Test
```powershell
python stress_test.py --clients 10 25 50
```
ผลแสดง success/error, average, median, p95, max latency, wall time และจำนวน TCP connections พร้อม ASCII graph และบันทึก `stress_results.csv` สำหรับนำไปทำกราฟใน PPT

## 12. ข้อจำกัด
- ใช้ HTTP แบบไม่เข้ารหัส จึง capture header ได้ เหมาะกับห้องทดลองเท่านั้น Production ควรใช้ TLS
- Session เก็บใน memory และหมดอายุ 1 ชั่วโมง เมื่อ restart Server session จะหาย
- Secret page ใช้ความลับของ path ไม่ใช่ authentication เต็มรูปแบบ
