"""QAP quiz server: sessions, flag chaining, uploads, and keep-alive."""

import base64
import binascii
import copy
import json
import mimetypes
import os
import socket
import threading
import time
import urllib.parse
import uuid
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

HOST = "0.0.0.0"
PORT = 8080
MAX_WORKERS = 50
MAX_HEADER_BYTES = 32 * 1024
MAX_BODY_BYTES = 8 * 1024 * 1024
MAX_IMAGE_BYTES = 5 * 1024 * 1024
SOCKET_TIMEOUT = 15
SESSION_TTL_SECONDS = 60 * 60
SECRET_FLAG = "I_KHOW_YOU_YOU_KNOW_I_AND_I_NEVER_GONNA_GIVE_YOU_UP"
SECRET_PATH = f"/{SECRET_FLAG}"

BASE_DIR = Path(__file__).resolve().parent
QUESTIONS_FILE = BASE_DIR / "questions.json"
IMAGES_DIR = BASE_DIR / "images"
WEB_DIR = BASE_DIR / "web"
SECRET_FILE = BASE_DIR / "secret" / "index.html"

with QUESTIONS_FILE.open("r", encoding="utf-8") as file:
    QUESTIONS = json.load(file)

SESSIONS = {}
SESSIONS_LOCK = threading.Lock()
QUESTIONS_LOCK = threading.Lock()
LOG_LOCK = threading.Lock()

STATUS_PHRASES = {
    200: "OK", 201: "CREATED", 400: "BAD_REQUEST", 401: "SESSION_REQUIRED",
    403: "FORBIDDEN", 404: "NOT_FOUND", 409: "CONFLICT", 413: "PAYLOAD_TOO_LARGE",
    415: "UNSUPPORTED_MEDIA_TYPE", 422: "INCOMPLETE", 431: "HEADERS_TOO_LARGE",
    500: "INTERNAL_SERVER_ERROR",
}


def log(message):
    with LOG_LOCK:
        print(f"[SERVER] {message}", flush=True)


def json_bytes(data):
    return json.dumps(data, ensure_ascii=False, separators=(",", ":")).encode("utf-8")


def make_response(code=200, body=b"", content_type="application/json; charset=utf-8", headers=None):
    if isinstance(body, str):
        body = body.encode("utf-8")
    return code, STATUS_PHRASES.get(code, "UNKNOWN"), content_type, body, headers or {}


def json_response(code, status_phrase=None, **payload):
    phrase = status_phrase or STATUS_PHRASES.get(code, "UNKNOWN")
    data = {"status": code, "status_phrase": phrase, **payload}
    return make_response(code, json_bytes(data))


def build_http_response(response, keep_alive=True):
    code, phrase, content_type, body, extra_headers = response
    lines = [
        f"HTTP/1.1 {code} {phrase}",
        f"Content-Type: {content_type}",
        f"Content-Length: {len(body)}",
        "X-Protocol: QAP",
        f"Connection: {'keep-alive' if keep_alive else 'close'}",
    ]
    lines.extend(f"{key}: {value}" for key, value in extra_headers.items())
    return ("\r\n".join(lines) + "\r\n\r\n").encode("utf-8") + body


def split_flag(fragment_count):
    """Split the flag into ordered fragments without losing characters."""
    base, remainder = divmod(len(SECRET_FLAG), fragment_count)
    fragments, offset = [], 0
    for index in range(fragment_count):
        size = base + (1 if index < remainder else 0)
        fragments.append(SECRET_FLAG[offset:offset + size])
        offset += size
    return fragments


def clean_expired_sessions():
    cutoff = time.time() - SESSION_TTL_SECONDS
    with SESSIONS_LOCK:
        expired = [sid for sid, session in SESSIONS.items() if session["last_seen"] < cutoff]
        for sid in expired:
            del SESSIONS[sid]


def start_session():
    clean_expired_sessions()
    with QUESTIONS_LOCK:
        snapshot = copy.deepcopy(QUESTIONS)
    session_id = uuid.uuid4().hex
    session = {
        "questions": snapshot,
        "answers": {},
        "score": 0,
        "fragments": split_flag(len(snapshot)),
        "awarded": {},
        "completed": False,
        "created_at": time.time(),
        "last_seen": time.time(),
        "lock": threading.Lock(),
    }
    with SESSIONS_LOCK:
        SESSIONS[session_id] = session
    return session_id, session


def get_session(headers):
    session_id = headers.get("x-session-id", "")
    if not session_id:
        return None, None, json_response(401, message="X-Session-ID header is required")
    with SESSIONS_LOCK:
        session = SESSIONS.get(session_id)
    if not session:
        return session_id, None, json_response(401, message="Unknown or expired session")
    session["last_seen"] = time.time()
    return session_id, session, None


def public_question(question):
    return {
        "id": question["id"],
        "question": question["question"],
        "images": question.get("images", []),
        "choices": question["choices"],
    }


def find_question(session, question_id):
    return next((q for q in session["questions"] if q["id"] == question_id), None)


def validate_image(content_type, data):
    signatures = {
        "image/png": (b"\x89PNG\r\n\x1a\n", ".png"),
        "image/jpeg": (b"\xff\xd8\xff", ".jpg"),
        "image/gif": (b"GIF8", ".gif"),
    }
    expected = signatures.get(content_type)
    if not expected:
        raise ValueError("Supported image types: image/png, image/jpeg, image/gif")
    signature, extension = expected
    if not data.startswith(signature):
        raise ValueError("Image bytes do not match content_type")
    return extension


def persist_questions():
    temporary = QUESTIONS_FILE.with_suffix(".json.tmp")
    with temporary.open("w", encoding="utf-8") as file:
        json.dump(QUESTIONS, file, ensure_ascii=False, indent=2)
        file.flush()
        os.fsync(file.fileno())
    os.replace(temporary, QUESTIONS_FILE)


def catalog_questions():
    with QUESTIONS_LOCK:
        items = [public_question(question) for question in QUESTIONS]
        return json_response(200, questions=items, total=len(items))


def unlink_unreferenced_images(image_paths):
    with QUESTIONS_LOCK:
        referenced = {image for question in QUESTIONS for image in question.get("images", [])}
    for image_path in image_paths:
        if image_path in referenced:
            continue
        filename = Path(image_path).name
        destination = (IMAGES_DIR / filename).resolve()
        try:
            destination.relative_to(IMAGES_DIR.resolve())
        except ValueError:
            continue
        destination.unlink(missing_ok=True)


def delete_question(question_id):
    with QUESTIONS_LOCK:
        if len(QUESTIONS) <= 1:
            return json_response(409, message="Cannot delete the last remaining question")
        index = next((i for i, question in enumerate(QUESTIONS) if question["id"] == question_id), None)
        if index is None:
            return json_response(404, message="Question not found")
        removed = QUESTIONS.pop(index)
        try:
            persist_questions()
        except OSError as error:
            QUESTIONS.insert(index, removed)
            return json_response(500, message=f"Could not delete question: {error}")
        removed_images = list(removed.get("images", []))

    unlink_unreferenced_images(removed_images)
    log(f">> RESPONSE: QAP 200 OK - Deleted question {question_id}")
    return json_response(200, message="Question deleted", question_id=question_id)


def create_question(body, headers):
    if "application/json" not in headers.get("content-type", ""):
        return json_response(415, message="Content-Type must be application/json")
    try:
        data = json.loads(body.decode("utf-8"))
        prompt = data["question"].strip()
        choices = data["choices"]
        answer = data["answer"]
        image = data["image"]
        content_type = image["content_type"].lower()
        encoded = image["data_base64"]
        if not prompt or not isinstance(choices, list) or len(choices) != 4:
            raise ValueError("question is required and choices must contain exactly 4 items")
        if not all(isinstance(choice, str) and choice.strip() for choice in choices):
            raise ValueError("Every choice must be a non-empty string")
        if isinstance(answer, bool) or not isinstance(answer, int) or not 0 <= answer < len(choices):
            raise ValueError("answer must be a valid zero-based choice index")
        if len(encoded) > (MAX_IMAGE_BYTES * 4 // 3) + 8:
            return json_response(413, message="Encoded image is too large")
        image_bytes = base64.b64decode(encoded, validate=True)
        if not image_bytes or len(image_bytes) > MAX_IMAGE_BYTES:
            return json_response(413, message="Image must be between 1 byte and 5 MiB")
        extension = validate_image(content_type, image_bytes)
    except (KeyError, TypeError, ValueError, UnicodeDecodeError, json.JSONDecodeError, binascii.Error) as error:
        return json_response(400, message=str(error))

    IMAGES_DIR.mkdir(parents=True, exist_ok=True)
    filename = f"upload_{uuid.uuid4().hex}{extension}"
    destination = IMAGES_DIR / filename
    temporary = destination.with_suffix(destination.suffix + ".tmp")
    try:
        temporary.write_bytes(image_bytes)
        os.replace(temporary, destination)
        with QUESTIONS_LOCK:
            question_id = max((q["id"] for q in QUESTIONS), default=0) + 1
            question = {
                "id": question_id,
                "question": prompt,
                "images": [f"images/{filename}"],
                "choices": choices,
                "answer": answer,
            }
            QUESTIONS.append(question)
            try:
                persist_questions()
            except Exception:
                QUESTIONS.pop()
                destination.unlink(missing_ok=True)
                raise
    except OSError as error:
        temporary.unlink(missing_ok=True)
        return json_response(500, message=f"Could not store question: {error}")

    log(f">> RESPONSE: QAP 201 CREATED - Question {question_id}")
    return json_response(201, question_id=question_id, image_url=f"/images/{filename}")


def handle_api_request(method, path, headers, body):
    if path == "/api/start" and method == "GET":
        session_id, session = start_session()
        log(f"<< REQUEST: START QAP")
        log(f">> RESPONSE: QAP 200 OK | X-Session-ID: {session_id}")
        return json_response(
            200,
            message="Quiz started",
            total_questions=len(session["questions"]),
            question_ids=[q["id"] for q in session["questions"]],
            **{"session_id": session_id},
        )[:-1] + ({"X-Session-ID": session_id},)

    if path == "/api/quiz/create" and method == "POST":
        log("<< REQUEST: CREATE /api/quiz/create QAP")
        return create_question(body, headers)

    if path == "/api/quiz/questions" and method == "GET":
        log("<< REQUEST: LIST /api/quiz/questions QAP")
        return catalog_questions()

    if path.startswith("/api/quiz/question/") and method == "DELETE":
        try:
            question_id = int(path.rsplit("/", 1)[1])
        except ValueError:
            return json_response(400, message="Invalid question ID")
        log(f"<< REQUEST: DELETE /api/quiz/question/{question_id} QAP")
        return delete_question(question_id)

    session_id, session, error = get_session(headers)
    if error:
        return error
    session_header = {"X-Session-ID": session_id}

    if path.startswith("/api/question/") and method == "GET":
        try:
            question_id = int(path.rsplit("/", 1)[1])
        except ValueError:
            return json_response(400, message="Invalid question ID")
        question = find_question(session, question_id)
        if not question:
            return json_response(404, message="Question not found")
        log(f"<< REQUEST: GET_Q /api/question/{question_id} QAP | Session: {session_id}")
        response = json_response(200, question=public_question(question))
        return response[:-1] + (session_header,)

    if path.startswith("/api/answer/") and method == "POST":
        try:
            question_id = int(path.rsplit("/", 1)[1])
            payload = json.loads(body.decode("utf-8"))
            answer = payload["answer"]
            if isinstance(answer, bool) or not isinstance(answer, int):
                raise ValueError("answer must be an integer")
        except (ValueError, KeyError, UnicodeDecodeError, json.JSONDecodeError) as error_value:
            return json_response(400, message=str(error_value))
        question = find_question(session, question_id)
        if not question:
            return json_response(404, message="Question not found")
        if not 0 <= answer < len(question["choices"]):
            return json_response(400, message="answer index is out of range")

        with session["lock"]:
            if question_id in session["answers"]:
                return json_response(409, message="Question already answered")
            all_same = len(set(question["choices"])) == 1
            correct = all_same or answer == question["answer"]
            session["answers"][question_id] = {"answer": answer, "correct": correct}
            q_index = next(i for i, item in enumerate(session["questions"]) if item["id"] == question_id)
            extra = dict(session_header)
            if correct:
                session["score"] += 1
                fragment = session["fragments"][q_index]
                session["awarded"][q_index + 1] = fragment
                extra["X-Flag-Fragment"] = fragment
                extra["X-Flag-Fragment-Index"] = str(q_index + 1)
                qap_status, qap_phrase = 201, "CORRECT"
            else:
                qap_status, qap_phrase = 202, "WRONG"

        log(f"<< REQUEST: ANSWER /api/answer/{question_id} QAP | Session: {session_id}")
        log(f">> RESPONSE: QAP {qap_status} {qap_phrase}")
        response = json_response(200, qap_status=qap_status, qap_phrase=qap_phrase, correct=correct)
        return response[:-1] + (extra,)

    if path == "/api/score" and method == "POST":
        with session["lock"]:
            missing = [q["id"] for q in session["questions"] if q["id"] not in session["answers"]]
            if missing:
                return json_response(422, message="Answer every question first", missing_question_ids=missing)
            session["completed"] = True
            score = session["score"]
            total = len(session["questions"])
            perfect = score == total and len(session["awarded"]) == total
            extra = dict(session_header)
        log(f"<< REQUEST: SCORE /api/score QAP | Session: {session_id}")
        log(f">> RESPONSE: QAP 200 OK | authoritative score {score}/{total}")
        response = json_response(200, score=score, total=total, perfect=perfect, fragments_earned=len(session["awarded"]))
        return response[:-1] + (extra,)

    return json_response(404, message="Endpoint not found")


def safe_static_file(root, relative_path):
    root = root.resolve()
    candidate = (root / relative_path).resolve()
    try:
        candidate.relative_to(root)
    except ValueError:
        return json_response(403, message="Invalid file path")
    if not candidate.is_file():
        return json_response(404, message="File not found")
    content_type = mimetypes.guess_type(candidate.name)[0] or "application/octet-stream"
    if content_type.startswith("text/"):
        content_type += "; charset=utf-8"
    return make_response(200, candidate.read_bytes(), content_type)


def dispatch_request(method, raw_path, headers, body):
    parsed = urllib.parse.urlsplit(raw_path)
    path = urllib.parse.unquote(parsed.path)
    if path.startswith("/api/"):
        return handle_api_request(method, path, headers, body)
    if path == SECRET_PATH:
        return safe_static_file(SECRET_FILE.parent, SECRET_FILE.name)
    if path in ("/", "/index.html"):
        return safe_static_file(WEB_DIR, "index.html")
    if path == "/score.html":
        return safe_static_file(WEB_DIR, "score.html")
    if path == "/create.html":
        return safe_static_file(WEB_DIR, "create.html")
    if path.startswith("/images/"):
        return safe_static_file(IMAGES_DIR, path[len("/images/"):])
    return json_response(404, message="Resource not found")


def parse_request(buffer, client_socket):
    while b"\r\n\r\n" not in buffer:
        if len(buffer) > MAX_HEADER_BYTES:
            raise ValueError("HEADERS_TOO_LARGE")
        chunk = client_socket.recv(4096)
        if not chunk:
            return None, buffer
        buffer += chunk

    marker = buffer.index(b"\r\n\r\n")
    if marker > MAX_HEADER_BYTES:
        raise ValueError("HEADERS_TOO_LARGE")
    header_block = buffer[:marker].decode("iso-8859-1")
    remaining = buffer[marker + 4:]
    lines = header_block.split("\r\n")
    parts = lines[0].split()
    if len(parts) != 3 or parts[2] not in ("HTTP/1.1", "HTTP/1.0"):
        raise ValueError("BAD_REQUEST")
    method, path, version = parts
    headers = {}
    for line in lines[1:]:
        if ":" not in line:
            raise ValueError("BAD_REQUEST")
        key, value = line.split(":", 1)
        headers[key.strip().lower()] = value.strip()
    try:
        content_length = int(headers.get("content-length", "0"))
    except ValueError as error:
        raise ValueError("BAD_REQUEST") from error
    if content_length < 0:
        raise ValueError("BAD_REQUEST")
    if content_length > MAX_BODY_BYTES:
        raise ValueError("PAYLOAD_TOO_LARGE")
    while len(remaining) < content_length:
        chunk = client_socket.recv(min(65536, content_length - len(remaining)))
        if not chunk:
            raise ConnectionError("Client disconnected during body")
        remaining += chunk
    body = remaining[:content_length]
    buffer = remaining[content_length:]
    return (method.upper(), path, version, headers, body), buffer


def handle_client(client_socket, address):
    log(f"Connection opened: {address}")
    client_socket.settimeout(SOCKET_TIMEOUT)
    buffer = b""
    try:
        while True:
            try:
                parsed, buffer = parse_request(buffer, client_socket)
                if parsed is None:
                    break
                method, path, version, headers, body = parsed
                wants_close = headers.get("connection", "").lower() == "close" or version == "HTTP/1.0"
                response = dispatch_request(method, path, headers, body)
                client_socket.sendall(build_http_response(response, keep_alive=not wants_close))
                if wants_close:
                    break
            except ValueError as error:
                code = {"HEADERS_TOO_LARGE": 431, "PAYLOAD_TOO_LARGE": 413}.get(str(error), 400)
                client_socket.sendall(build_http_response(json_response(code, message=str(error)), keep_alive=False))
                break
    except (ConnectionError, socket.timeout, ConnectionResetError, BrokenPipeError):
        pass
    except Exception as error:
        log(f"Unhandled error for {address}: {error}")
        try:
            client_socket.sendall(build_http_response(json_response(500, message="Internal server error"), keep_alive=False))
        except OSError:
            pass
    finally:
        client_socket.close()
        log(f"Connection closed: {address}")


def main():
    server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    server_socket.bind((HOST, PORT))
    server_socket.listen(100)
    print("=" * 64)
    print(" QAP Server - sessions, flag fragments, upload, keep-alive")
    print(f" Web: http://127.0.0.1:{PORT}/")
    print(f" Create question: http://127.0.0.1:{PORT}/create.html")
    print("=" * 64, flush=True)
    try:
        with ThreadPoolExecutor(max_workers=MAX_WORKERS, thread_name_prefix="qap") as executor:
            while True:
                client_socket, address = server_socket.accept()
                executor.submit(handle_client, client_socket, address)
    except KeyboardInterrupt:
        print("\n[SERVER] Shutting down...")
    finally:
        server_socket.close()


if __name__ == "__main__":
    main()
