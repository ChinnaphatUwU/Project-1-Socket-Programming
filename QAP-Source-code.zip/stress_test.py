"""QAP load test and keep-alive benchmark. Start server.py before running."""

import argparse
import csv
import json
import statistics
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path

from client import QAPClient

BASE_DIR = Path(__file__).resolve().parent


def answer_map():
    with (BASE_DIR / "questions.json").open("r", encoding="utf-8") as file:
        questions = json.load(file)
    return {question["id"]: question["answer"] for question in questions}


def run_game(keep_alive=True, verbose=False):
    answers = answer_map()
    started = time.perf_counter()
    client = QAPClient(keep_alive=keep_alive, verbose=verbose)

    try:
        _, _, start = client.request("GET", "/api/start")
        for question_id in start["question_ids"]:
            client.request("GET", f"/api/question/{question_id}")
            client.request("POST", f"/api/answer/{question_id}", {"answer": answers[question_id]})
        _, _, score = client.request("POST", "/api/score", {})
        success = score.get("perfect") is True and len(client.fragments) == score.get("total")
        return {
            "success": success,
            "elapsed_ms": (time.perf_counter() - started) * 1000,
            "connections": client.connection_count,
            "score": score.get("score", 0),
            "total": score.get("total", 0),
            "error": "",
        }
    except Exception as error:
        return {
            "success": False,
            "elapsed_ms": (time.perf_counter() - started) * 1000,
            "connections": client.connection_count,
            "score": 0,
            "total": 0,
            "error": str(error),
        }
    finally:
        client.close()


def summarize(label, clients, results):
    elapsed = [result["elapsed_ms"] for result in results]
    successes = sum(result["success"] for result in results)
    connections = sum(result["connections"] for result in results)
    return {
        "test": label,
        "clients": clients,
        "successes": successes,
        "errors": clients - successes,
        "success_rate_pct": round(successes * 100 / clients, 2),
        "avg_ms": round(statistics.mean(elapsed), 2),
        "median_ms": round(statistics.median(elapsed), 2),
        "p95_ms": round(sorted(elapsed)[min(len(elapsed) - 1, int(len(elapsed) * 0.95))], 2),
        "max_ms": round(max(elapsed), 2),
        "tcp_connections": connections,
    }


def concurrent_test(client_count, keep_alive=True):
    started = time.perf_counter()
    with ThreadPoolExecutor(max_workers=client_count) as pool:
        futures = [pool.submit(run_game, keep_alive) for _ in range(client_count)]
        results = [future.result() for future in as_completed(futures)]
    summary = summarize("keep-alive" if keep_alive else "connection-close", client_count, results)
    summary["wall_time_ms"] = round((time.perf_counter() - started) * 1000, 2)
    return summary, results


def print_table(summaries):
    columns = ["test", "clients", "successes", "errors", "avg_ms", "p95_ms", "wall_time_ms", "tcp_connections"]
    widths = {column: max(len(column), *(len(str(row[column])) for row in summaries)) for column in columns}
    print(" | ".join(column.ljust(widths[column]) for column in columns))
    print("-+-".join("-" * widths[column] for column in columns))
    for row in summaries:
        print(" | ".join(str(row[column]).ljust(widths[column]) for column in columns))


def print_ascii_graph(summaries):
    print("\nAverage response time per complete game")
    maximum = max(row["avg_ms"] for row in summaries) or 1
    for row in summaries:
        bar = "#" * max(1, round(row["avg_ms"] / maximum * 40))
        print(f"{row['test']:18} ({row['clients']:2} clients) {bar} {row['avg_ms']} ms")


def write_csv(path, summaries):
    with open(path, "w", newline="", encoding="utf-8-sig") as file:
        writer = csv.DictWriter(file, fieldnames=list(summaries[0].keys()))
        writer.writeheader()
        writer.writerows(summaries)


def main():
    parser = argparse.ArgumentParser(description="QAP concurrent load and connection benchmark")
    parser.add_argument("--clients", type=int, nargs="+", default=[10, 25, 50])
    parser.add_argument("--csv", default="stress_results.csv")
    args = parser.parse_args()

    print("QAP benchmark: server.py must already be running on 127.0.0.1:8080\n")
    summaries = []

    print("Connection optimization comparison (one client):")
    persistent, _ = concurrent_test(1, keep_alive=True)
    reconnect, _ = concurrent_test(1, keep_alive=False)
    summaries.extend([persistent, reconnect])
    print_table([persistent, reconnect])
    reduction = reconnect["tcp_connections"] - persistent["tcp_connections"]
    print(f"\nKeep-alive removes {reduction} TCP connection setups per game ")
    print(f"({reconnect['tcp_connections']} -> {persistent['tcp_connections']}).\n")

    print("Concurrent keep-alive players:")
    load_summaries = []
    for count in args.clients:
        summary, results = concurrent_test(count, keep_alive=True)
        summaries.append(summary)
        load_summaries.append(summary)
        failures = [item["error"] for item in results if item["error"]]
        if failures:
            print(f"{count} clients: first error: {failures[0]}")
    print_table(load_summaries)
    print_ascii_graph(summaries)
    write_csv(args.csv, summaries)
    print(f"\nCSV saved to {args.csv}")


if __name__ == "__main__":
    main()
